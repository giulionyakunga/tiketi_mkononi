String app_name = "Tiketi Mkononi";
String company_name = "TELabs";

// String backend_url = 'http://192.168.78.31:8085/';
// String backend_url = 'http://localhost:8085/';
String backend_url = 'http://telabs.co.tz:8085/';

// String backend_ws_url = 'ws://192.168.78.31:8086';
// String backend_ws_url = 'ws://localhost:8086';
String backend_ws_url = 'ws://telabs.co.tz:8086';